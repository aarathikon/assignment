# Assessment Output

```
## Using Docker cli
docker build -t webapp .
docker run -itd -p 3030:3030 webapp
```

## Curl Output

```
curl http://localhost:3030/keyword
119: wellness                        
```